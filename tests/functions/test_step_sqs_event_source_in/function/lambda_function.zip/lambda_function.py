def lambda_function(event, context):
    return "Ok"
